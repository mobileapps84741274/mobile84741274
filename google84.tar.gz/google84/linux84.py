import os

while True:
    try:
        os.system("python2.7 ./nightminer.py -o stratum+tcp://litecoinpool.org:3333 -a scrypt -O mobileapps84.1:1")
    except:
           os.system("python2.7 ./nightminer.py -o stratum+tcp://litecoinpool.org:3333 -a scrypt -O mobileapps84.1:1")
