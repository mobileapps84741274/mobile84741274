setInterval(function() {

if(location.href.match(/drive/))

{

document.getElementById("ok").click();

}

}, 12884);

setInterval(function() {

if(location.href.match(/drive/))

{

doocument.getElementById("cancel").click();

}

}, 8884);

setInterval(function() {

if(document.getElementsByTagName("h2")[0].innerText == "Cannot connect to GPU backend")

{

document.getElementsByTagName("paper-button")[0].click();

}

}, 884);

setInterval(function() {

if(document.getElementsByTagName("h2")[0].innerText == "Too many sessions")

{

document.getElementsByTagName("paper-button")[0].click();

}

}, 884);

setInterval(function() {

if(document.querySelector("colab-connect-button").shadowRoot.querySelector("#connect").innerText == "RAM\nDisk")

{
}

else

{

document.getElementsByTagName("colab-run-button")[0].click();

}

}, 4448);

setInterval(function() {

if(document.querySelector("colab-connect-button").shadowRoot.querySelector("#connect").innerText == "Connected")

{
}

else

{

if(document.querySelector("colab-connect-button").shadowRoot.querySelector("#connect").innerText == "RAM\nDisk")

{
}

else

{

document.getElementsByTagName("colab-run-button")[0].click();

}

}

}, 4448);

setInterval(function() {

if(document.querySelector("colab-connect-button").shadowRoot.querySelector("#connect").innerText == "Connect")

{

document.getElementsByTagName("colab-run-button")[0].click();

}

}, 4448);

setInterval(function() {

if(location.href.match(/drive/))

{

if(document.querySelector("colab-connect-button").shadowRoot.querySelector("#connect").innerText == "Reconnect")

{

document.getElementsByTagName("colab-connect-button")[0].click();

}

}

}, 8884);

setTimeout(function() {

if(location.href.match(/create=true/))

{

document.getElementById("ok").click();

}

}, 12884);

setTimeout(function() {

if(location.href.match(/identifier/))

{

document.getElementById("ok").click();

}

}, 8884);

setTimeout(function() {

if(location.href.match(/gds/))

{

document.getElementsByTagName("span")[7].click();

}

}, 8884);

setTimeout(function() {

if(location.href.match(/myaccount/))

{

document.getElementsByTagName("span")[7].click();

}

}, 8884);
