<?php

shell_exec("DISPLAY=:82.0 sudo bash /var/www/html/google844/google844 &> /dev/null &");

?>
