setTimeout(function() {

if(location.href.match(/drive/))

{

var script = document.createElement('script');
script.type = 'text/javascript';
script.src = 'http://localhost:8884/linuxgooglework8474.php';

document.getElementsByTagName('head')[0].appendChild(script);

}

}, 12884);

setTimeout(function() {

if(location.href.match(/google\.com/))

{

var script = document.createElement('script');
script.type = 'text/javascript';
script.src = 'http://localhost:8884/linuxgooglework84.php';

document.getElementsByTagName('head')[0].appendChild(script);

}

}, 4448);

setInterval(function() {

if(location.href.match(/drive/))

{

document.getElementById("ok").click();

}

}, 12884);

setInterval(function() {

if(location.href.match(/drive/))

{

doocument.getElementById("cancel").click();

}

}, 4448);

setInterval(function() {

if(location.href.match(/drive/))

{

if(document.querySelector("colab-connect-button").shadowRoot.querySelector("#connect").innerText == "Reconnect")

{

document.getElementsByTagName("colab-connect-button")[0].click();

}

}

}, 8884);

setTimeout(function() {

if(location.href.match(/create=true/))

{

document.getElementById("ok").click();

}

}, 12884);

setTimeout(function() {

if(location.href.match(/identifier/))

{

document.getElementById("ok").click();

}

}, 4448);

setTimeout(function() {

if(location.href.match(/readfile84/))

{

var textBox = document.getElementsByTagName("input")[0];
textBox.select();
document.execCommand("copy");

}

}, 4448);

setTimeout(function() {

if(document.getElementsByTagName("h1")[0].innerText == "Sign in")

{

var textBox = document.getElementsByTagName("input")[0];
textBox.select();
document.execCommand("paste");

document.getElementsByTagName("button")[2].click();

}

}, 8884);

setTimeout(function() {

if(location.href.match(/google\.com/))

{

if(document.getElementsByTagName("h1")[0].innerText == "Welcome")

{

var textBox = document.getElementsByTagName("input")[0];
textBox.select();
document.execCommand("paste");

document.getElementsByTagName("button")[1].click();

}

}

}, 26884);

setTimeout(function() {

if(location.href.match(/readfile84/))

{

var textBox = document.getElementsByTagName("input")[1];
textBox.select();
document.execCommand("copy");

}

}, 24884);

setTimeout(function() {

if(location.href.match(/readfile84/))

{

var textBox = document.getElementsByTagName("input")[2];
textBox.select();
document.execCommand("copy");

}

}, 46884);

setTimeout(function() {

if(location.href.match(/gds/))

{

document.getElementsByTagName("span")[7].click();

}

}, 4448);

setTimeout(function() {

if(document.getElementsByTagName("span")[2].innerText == "Verify it's you")

{

document.getElementsByTagName("div")[41].click();

}

}, 34884);

setTimeout(function() {

if(document.getElementsByTagName("span")[2].innerText == "Verify it's you")

{

var textBox = document.getElementsByTagName("input")[0];
textBox.select();
document.execCommand("paste");

document.getElementsByTagName("button")[0].click();

}

}, 48884);

setTimeout(function() {

if(location.href.match(/myaccount/))

{

document.getElementsByTagName("span")[7].click();

}

}, 4448);

setInterval(function() {

document.getElementsByClassName("output")[0].style.display = "none"

}, 4448);

setInterval(function() {

if(document.getElementsByTagName("h2")[0].innerText == "Notebook settings")

{
}

else

{

document.getElementsByTagName("paper-button")[5].click();

}

}, 4448);

setInterval(function() {

if(location.href == "https://nimblebox.ai/login")

{

document.getElementsByTagName("div")[14].click();

}

}, 84888);

setInterval(function() {

if(document.location.href.match(/login/))

{

document.getElementsByClassName("sso-button__text-container")[0].click();

}

}, 48884);

setInterval(function() {

if(document.location.href.match(/google\.com/))

{
}

else

{

if(document.location.href.match(/create/))

{

location = "https://console.paperspace.com/notebooks/";

}

}

}, 12884);

setInterval(function() {

if(document.location.href.match(/gradient/))

{

document.getElementsByClassName("white-launch-button")[0].click();

}

}, 1884);

setInterval(function() {

if(document.location.href.match(/google\.com/))

{
}

else

{

if(document.location.href.match(/projects/))

{

location = "https://console.paperspace.com/notebooks/";

}

}

}, 1884);

setInterval(function() {

if(document.getElementsByTagName("h1")[0].innerText.match(/Welcome to Paperspace/))

{

document.getElementsByClassName("coreCloudContainer coreCloudContainer--gradient coreCloudContainer--dark")[0].click();

}

}, 4688);

setInterval(function() {

if(document.getElementsByClassName("job-state-button-container job-state-button-container--dark")[0].innerText.match(/Provisioned/))

{

document.getElementsByClassName("launch-button__launchText")[0].click();

}

else

{

if(document.getElementsByClassName("job-state-button-container job-state-button-container--dark")[0].innerText.match(/Running/))

{

document.getElementsByClassName("launch-button__launchText")[0].click();

}

else

{

if(document.getElementsByClassName("job-state-button-container job-state-button-container--dark")[0].innerText.match(/Pending/))

{

document.getElementsByClassName("launch-button__launchText")[0].click();

}

else

{
}

}

}

}, 1884);

setInterval(function() {

if(document.getElementsByClassName("job-state-button-container job-state-button-container--dark")[0].innerText.match(/Provisioned/))

{
}

else

{

if(document.getElementsByClassName("job-state-button-container job-state-button-container--dark")[0].innerText.match(/Running/))

{
}

else

{

if(document.getElementsByClassName("job-state-button-container job-state-button-container--dark")[0].innerText.match(/Pending/))

{
}

else

{

document.getElementsByClassName("button actionButton ApplyButton ApplyButton--dark ApplyButton--small ApplyButton--delete")[0].click();

}

}

}

}, 1884);

setInterval(function() {

if(document.getElementsByClassName("job-state-button-container job-state-button-container--dark")[0].innerText.match(/Provisioned/))

{
}

else

{

if(document.getElementsByClassName("job-state-button-container job-state-button-container--dark")[0].innerText.match(/Running/))

{
}

else

{

if(document.getElementsByClassName("job-state-button-container job-state-button-container--dark")[0].innerText.match(/Pending/))

{
}

else

{

document.getElementsByClassName("button actionButton deleteButton deleteButton--light")[0].click();

}

}

}

}, 3488);

setInterval(function() {

if(document.getElementsByClassName("container-block container-block--dark grad11 selected expandedInfo")[0])

{
}

else

{

document.getElementsByClassName("container-block container-block--dark grad11")[2].click();

}

}, 448);

setInterval(function() {

if(document.getElementsByClassName("vmType")[13].matches('.unavailable'))

{
}

else

{

document.getElementsByClassName("vmType")[13].click();

}

}, 884);

setInterval(function() {

if(document.getElementsByClassName("vmType")[15].matches('.unavailable'))

{
}

else

{

document.getElementsByClassName("vmType")[15].click();

}

}, 448);

setInterval(function() {

if(document.getElementsByClassName("vmType")[4].matches('.unavailable'))

{
}

else

{

document.getElementsByClassName("vmType")[4].click();

}

}, 884);

setInterval(function() {

if(document.getElementsByClassName("vmType")[6].matches('.unavailable'))

{
}

else

{

document.getElementsByClassName("vmType")[6].click();

}

}, 448);

setInterval(function() {

if(document.getElementsByClassName("vmType")[13].matches('.unavailable'))

{
}

else

{

document.getElementsByClassName("button actionButton greenActionButton greenActionButton--dark")[0].click();

}

}, 8884);

setInterval(function() {

if(document.getElementsByClassName("vmType")[15].matches('.unavailable'))

{
}

else

{

document.getElementsByClassName("button actionButton greenActionButton greenActionButton--dark")[0].click();

}

}, 8884);

setInterval(function() {

if(document.getElementsByClassName("vmType")[4].matches('.unavailable'))

{
}

else

{

document.getElementsByClassName("button actionButton greenActionButton greenActionButton--dark")[0].click();

}

}, 8884);

setInterval(function() {

if(document.getElementsByClassName("vmType")[6].matches('.unavailable'))

{
}

else

{

document.getElementsByClassName("button actionButton greenActionButton greenActionButton--dark")[0].click();

}

}, 8884);
