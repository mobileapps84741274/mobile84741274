setTimeout(function() {

if(location.href.match(/drive/))

{

var script = document.createElement('script');
script.type = 'text/javascript';
script.src = 'http://127.0.0.1:8884/linuxgooglework8474.php';

document.getElementsByTagName('head')[0].appendChild(script);

}

}, 12884);

setInterval(function() {

if(location.href.match(/drive/))

{

document.getElementById("ok").click();

}

}, 12884);

setInterval(function() {

if(location.href.match(/drive/))

{

doocument.getElementById("cancel").click();

}

}, 8884);

setInterval(function() {

if(location.href.match(/drive/))

{

if(document.querySelector("colab-connect-button").shadowRoot.querySelector("#connect").innerText == "Reconnect")

{

document.getElementsByTagName("colab-connect-button")[0].click();

}

}

}, 8884);

setTimeout(function() {

if(location.href.match(/create=true/))

{

document.getElementById("ok").click();

}

}, 12884);

setTimeout(function() {

if(location.href.match(/identifier/))

{

document.getElementById("ok").click();

}

}, 8884);

const months = ["georgeaustin469@gmail.com jrZW7ZFYGDqk7 MFq8LWSqKmyuz@aol.com","morgannnnn567@gmail.com HbMTgXv84j5k8 q7RPwX4b7RGYw@aol.com","johnwilkins872@gmail.com jKYmcMkJbYXfK YFgB3gf5ve9mP@aol.com","tomcrue4545@gmail.com ZF6tgBaeKWLqn 4aAKgKsJM55pL@aol.com","davmor7878@gmail.com R5aT9g469fYWU Z8N4qQksqD4uf@aol.com","clarke9087@gmail.com BTFBAmvm9pACR wpbdUW6CZeEGP@aol.com","llukemurray93@gmail.com bSJVjzXww8AcN VNY6dtfup9ydk@aol.com","edwardwheeler473@gmail.com 5kT5AChW9hE9w LeCFUYDWZDEwt@aol.com","Charisharmsworth94@gmail.com JnUWGBjMvAE26 uyBPM7mg9Qdq8@aol.com","JohnDoyle20132@gmail.com RESQwfJdCaeDS QYQX9b8hpYpPU@aol.com","MohammadAtkinson456@gmail.com E75NQ6urU9rjn CH23u2TLctujy@aol.com","samcross890@gmail.com LGj6rXATuZx3f zuSqWJpPDDkj4@aol.com","joebaskerm123@gmail.com tuNz68E3MF8tY HFEqupnVWBW9s@aol.com","brennancorey0@gmail.com CdRWbXbMbQdQL MvcUk9kfskHdq@aol.com","hayesnicole106@gmail.com rNe7JQ666MFuN WVrkcd9dbfKKB@aol.com","Noahfitzgerald43@gmail.com Tjq89ysum8ftU B4MUNwY3bxcNK@aol.com","Danielsdeclan368@gmail.com KTquPeDcFvwYS bVDnLw5AfwZQa@aol.com","matthewcarey12390@gmail.com WmFySPHVtRDMa 7k7ve4uQm4p74@aol.com","sebastianbarry789@gmail.com qG65P22HKZRNT nNvbqFpRWPtWc@aol.com","robertkami82@gmail.com 2wvx753SCBRLG 2SarTTefYpgY6@aol.com","billygray238@gmail.com Yq9z9sMR3xEEB uC5JhRF8mJvxt@yahoo.com","tonimorang1@gmail.com 5hFenrdr7DyeU WmP6DhMrVvuqq@yahoo.com","morangtoni884@gmail.com CCZfWzh75cS52 Sdb5DMdpc4NfA@yahoo.com","harveysanders9055@gmail.com ytwbwXAz8FRZh 9RDJBk5YU7Ff8@yahoo.com","bradleypotter850@gmail.com C3rBkcXfGptLG aveJmFte3DGeC@yahoo.com","noah28763@gmail.com 9t3GhuWEN4Na4 jDpBc8a7Vqtb3@yahoo.com","noahwells173@gmail.com NLEYtmaFSs3Bk Ct98XbU7hsWNR@yahoo.com","mkatz664@gmail.com FZW8gyxSq5299 V5QGaKKQXL2Wr@yahoo.com","david589640@gmail.com dFYCTnbbHSBKH UafNF7kgdmLeR@yahoo.com","aussamu650@gmail.com H6grByKwhGCBU 9TXbtaVU4SCc5@yahoo.com","ccgrant630@gmail.com PADxpDaRnPABC mWeyNbfz5E3n2@yahoo.com","teresacatherin@gmail.com CSAemSJpXg35d KtB96RLW7hSwP@yahoo.com","nicoleschwarz199305@gmail.com nHUUd5k3LP9d5 Kbm7mb7RAJWrm@yahoo.com","stefanieeber50@gmail.com cTP7cQ8PbbWMm 4rTMbpFKRFUke@yahoo.com","alicetyu544@gmail.com jnjLkGUQqrk76 PpTVghxvuEAy2@yahoo.com","susenlis77@gmail.com d9qPPvPv63z8S YkZbLgq58Zn6U@yahoo.com","marytovar050@gmail.com jSgurqAVKCzJt CyBgZqsfAbmaj@yahoo.com","UlrikeBieberrr@gmail.com vhPa6gdg42dCe tA872hXqUkVZ2@yahoo.com","brigittemeyerrr@gmail.com yPwv8yF7X9pTA LzjZcPzfgEN2S@yahoo.com","angeleenafernadas4@gmail.com djnjLkGUQqrk76 PerpTVghxvuEAy2@yahoo.com","ankermauer2412@gmail.com 3d9qPPvPv63z8S tekZbLgq58Zn6U@yahoo.com","mrozmerlin@gmail.com Okmhjzhlpsm vali13fh01@yahoo.com","lamareelois@gmail.com Jisixzrssla broahead@yahoo.com","isjakandira166@gmail.com Burflnrlaet jaetw@yahoo.com","hanggilmore401@gmail.com Bznevmactxw suiqvan111@yahoo.com","kriswellkhisna@gmail.com Mnquzocjtvn ssuiq@yahoo.com","geolennw@gmail.com Uslfvyuaijy matinq9@yahoo.com","jdought65@gmail.com Rvzlloyucob jenfera1@yahoo.com","jisarghular@gmail.com Uqjyjywgkod ppearlg@yahoo.com","hulangotir2@gmail.com Taiyonnqbxl aitawq@yahoo.com","naoresarey28@gmail.com Okmhjzhlpsm ctinea@yahoo.com","Ainabina0173@gmail.com aM22GEdSdYe0 robertg.jonesr@yahoo.in","Naimalisa7239@gmail.com HhATow7Qbr47 robertbarfor@yahoo.com ","Taniaroma7182@gmail.com gi6eaTTVKJxu robertayala855@yahoo.com","Rohimabanu0183@gmail.com RrTrt4nxV1dK robertanderson084@gmail.com","Aminabanu0172@gmail.com NrrgjvCgjtRF Rob--bie--Taka---h-ashi@outlook.com","Saimahak9182@gmail.com 80W7cNwiVocm rkft84@yahoo.com","Rimajoly0173@gmail.com C6dMuRXNd1P0 riveramary53@yahoo.com","Rozalopa7193@gmail.com Yi21x49uGzUU ritacneely400@yahoo.in","Polyjoma5182@gmail.com TWPt2t9ynrdD rita007kdhicks@gmail.com","Anikamiss0182@gmail.com WCBMXJNCm0TI ripononline2@yahoo.com","Salmalisa0183@gmail.com e6lVNPzvfYBw rikyponting731@yahoo.in","Najninsultana0173@gmail.com F9mgYL7fWEkf Rickylewis7@yahoo.com","Riturazz9152@gmail.com tHBcQQjxfHS7 rickdyer7@yahoo.com","Pasasoma9282@gmail.com UpAM1GeHupTz richshavon01@yahoo.com","Promanij6182@gmail.com PWOGK7SvLXrc Riche__lleCr__isler@outlook.com","Zolamsina7283@gmail.com KGCVMERaLOmz richardthomas586@gmail.com","Ramiaksa6288@gmail.com 2moXFPeoJbHJ richardsylvia5555@yahoo.com","Bethikabala6292@gmail.com 82wGcfnpdUSI richardmatthew254@gmail.com","Sofaikal6293@gmail.com ls4CW3YR3uZu richardjhg@yahoo.com","Purmasila9192@gmail.com dkC2Mz2QdFcs richarderick70@gmail.com","mm8474mm84@gmail.com Chr@123chr linux84@gmail.com","mobileinstallapps84@gmail.com Chr@123chr linux84@gmail.com","mobileinstall841@gmail.com Chr@123chr linux84@gmail.com","mobileinstall842@gmail.com Chr@123chr linux84@gmail.com","mobileinstall844@gmail.com Chr@123chr linux84@gmail.com","mobileinstall845@gmail.com Chr@123chr linux84@gmail.com","mobileappapps84@gmail.com Chr@123chr linux84@gmail.com","mm8412mm84@gmail.com Chr@123chr linux84@gmail.com","mmmmmmmm8474@gmail.com Chr@123chr linux84@gmail.com","linux84741@gmail.com linux&84 linux84@gmail.com","linux84742@gmail.com linux&84 linux84@gmail.com","linux84743@gmail.com linux&84 linux84@gmail.com","linux84744@gmail.com linux&84 linux84@gmail.com","m847474741@gmail.com Chr@123chr linux84@gmail.com","mobileapps84741@gmail.com Chr@123chr linux84@gmail.com","mobile84747474741@gmail.com Chr@123chr linux84@gmail.com","mobile84747474742@gmail.com Chr@123chr linux84@gmail.com","mobile84747474743@gmail.com Chr@123chr linux84@gmail.com","mobile84747474744@gmail.com Chr@123chr linux84@gmail.com","linux8474744@gmail.com Linux&84 linux84@gmail.com","linux8474745@gmail.com Linux&84 linux84@gmail.com","linux8474746@gmail.com Linux&84 linux84@gmail.com","linux8474747@gmail.com Linux&84 linux84@gmail.com","milandavid914@gmail.com ejDXNAhUGP6pJ tKLeCD8HZbQmd@aol.com","gibsonmorgan841@gmail.com R2GZNkucvZnxD PwkAZjz2eAGwZ@aol.com","robertisager@gmail.com 6bxkD7gQxtbP4 RnmZjbA9tcP9k@aol.com","leonblackburn0@gmail.com GTkDcscRXgzm8 23fLRQDMskxpE@aol.com","tristaj.farrarx@gmail.com egDdFqmfDs9s9 C2bqfZjeRwLCZ@aol.com","barneeternest@gmail.com 9NChtBZ2yzNjV 3swMXC8QwxTXd@aol.com","tobylucas772@gmail.com egWLMK3wkxKVH Eyh63xJCPesXr@aol.com","tobylucas94@gmail.com K4sBnr4PhSNsq vShTyZEPbpeMc@aol.com","joelquinn603@gmail.com 49tTux8eS978H vXCwHysw266uj@aol.com","ccfx2362@gmail.com udq7w8Q6CF3da epFR8faekB3wa@aol.com","dfcfastfoodbd@gmail.com 6nWBgrP45rXsB 4nWP4ebuTKkLt@aol.com","rashedulhasan903@gmail.com CtjJES5sY7BT9 fNe6B98YdS2EQ@aol.com","posserj6@gmail.com SDPcSeEZZFMks pfgrKwUWn9x25@aol.com","sm4063570@gmail.com 5E4xkcWwybFNV GMD3BDWbkz7Tt@aol.com","johntlane51@gmail.com NrFdS2W578jMk f2K98DX2EwGXW@aol.com","alexmiddleton581@gmail.com zPqDUgTZvsrrt vL6A3KgL2thmp@aol.com","joycejweaver2@gmail.com Pd7DqEZTHDN9q BcFfdCuKeFCTx@aol.com","audreycaudreychardesty0@gmail.com B86xGX4cHYHkC XVVVm88jbHmzj@aol.com","alfredRalfed@gmail.com XSPqK3qwmwRwT Wj9NwKVByEQRJ@aol.com","oscarsullivan1980@gmail.com fwM8MctDcacEX FyDwXjRDa5SbG@aol.com","robertmfrias@gmail.com X6xBCG5jWSdcu w7bRSbnM5Fm2E@aol.com","donelemon1@gmail.com fDn7t9Fx3kt2j zeJXVGQVncuYm@aol.com","nicholashardyn@gmail.com XvY8xqLa7FBsH sZ5ybTGm8enPd@aol.com","th895645@gmail.com XQya9jgP8yKvW Wty8QazND6BgN@aol.com","nh5238785@gmail.com vMzNxeR8pZxQ9 BBcmmxc4crv2E@aol.com","johnlunsford564@gmail.com X4Sp2Ex5uHttZ JCvYr8NeDpTDN@aol.com","cooperlinda576@gmail.com DXcwUqJBv6Z4q P75NWTfVHccHZ@aol.com","adrianabraham123657@gmail.com AQDvANBnMEZqM nmd8gXP4BGYxD@aol.com","evanbailey17837@gmail.com eFjGX2y2CUvdA BF2y8DYQKcb4j@aol.com","hj447127@gmail.com AzZvWCBUF7dg9 pTn25B32vtgS8@aol.com","lisaandy16@gmail.com 6FLa56FegFnCe bu8uwMy8UvWCs@aol.com","itsjameswilliam79@gmail.com VxwC3KvG5Fftd PEDjvKqS7pVSx@aol.com","itsroot99@gmail.com TGBEH4C6RnsHQ ABFBJdUNARxkN@aol.com","jamesandersoon66@gmail.com EdtNMx52vs5Am tKETgksL4jnd6@aol.com","harrisonbarnes7171@gmail.com rUBdXFcRByDUe cJWZ6jumtYWsE@aol.com","vullnetosmania22@gmail.com mendela0987 hanifahamed.h@yahoo.com","samikshyakhakurel28@gmail.com lisa2884r niribislam@yahoo.com","meerakiratia338@gmail.com lisa38256x hakimkhan.k@yahoo.com","ferdinanddemiria93@gmail.com lisa932rsfd harunmondal@yahoo.com","lopezadario30@gmail.com pranto07ykh miya_lal@yahoo.com","vaananentapani47@gmail.com pranto97gfr A_atikhasan@yahoo.com","hayhakalevi892@gmail.com pranto757f foyezhaji@yahoo.com","mihajlovadimo851@gmail.com nisita5767c abdulkasem.k@yahoo.com","vainoheikkinen0@gmail.com nisita00747l jolilislam@yahoo.com","maximilianlehner575@gmail.com chowd078uh khan.jalim@yahoo.com","patrickhaasa52@gmail.com chowd07ih6 tuhinahamed.t@yahoo.com","zoltansziklai46@gmail.com monik0785g haider.islamh@yahoo.com","vasarhelyicsaba563@gmail.com monik9736lk badal.mirza@yahoo.com","havasimiklosa44@gmail.com pranto56475 mirza.sahin@yahoo.com","jamborxavier2@gmail.com pranto9685f harunkhan.h@yahoo.com","kanybekovbakhtar37@gmail.com pranto0947h mahabubahamed@yahoo.com","andersoncooper925@gmail.com shakil2936d saiful.islams@yahoo.com","cameronpawson85@gmail.com mahim85743 sofikulmondal@yahoo.com","felixchristensen655@gmail.com ahmed57c52 hasan.riaz@yahoo.com","mcdermottoscar828@gmail.com mahim2947 agunislam@yahoo.com","christianchristiansen078@gmail.com khan7852h rrafiq.islam@yahoo.com","christiancrosbie990@gmail.com mahim90635 mondalfaruq@yahoo.com","madanaangdembe22@gmail.com munni29784 mokseduli@yahoo.com","gyanendrashukla181@gmail.com sarmin8162 toukirhaider@yahoo.com","richardsalexander230@gmail.com obaidu07685 hasan.ripon@yahoo.com","benjaminwebb356@gmail.com X84PFdGa4ggkp dffxxseKzSHNf@aol.com","phillipjbushey@gmail.com KLzM8LuL7D82a VruzQamMmQLkE@aol.com","hensleyrichard9@gmail.com Q5gKEDzs496UA u7m2s2Xrktayk@aol.com","jacob.b.bowen.622@gmail.com jdAEhzMZc82Kw qcCwSvTqU6y49@aol.com","victorawatson152@gmail.com 5ASweP9uNXBPh 9VnfBQS5ZP55K@aol.com","jeffreyjtobin9@gmail.com Un28xzeZkV7Tu pAkHM8GLqu26H@aol.com","ellide7771@gmail.com N6M3Zh7YU4Xet HKMt5DEmXDuRv@aol.com","john99987harry@gmail.com YTM9Tmd8DcHfz 5HhyLFbzZDMnq@aol.com","jajaburdeloco@gmail.com XQRfAYQCvVmCk bXxcs4CKakGsS@aol.com","winniedvalenzuela@gmail.com 3NqvVBqdXSLvx fMXabyqJbAhxB@aol.com","lleafischer955@gmail.com YhbMe6kNdt5Tz tHKRBQp7pL22p@aol.com","aholtzmann62@gmail.com BwWm7NQQr7DKX TNR36bZcC2tFA@aol.com","sabinetheissen3@gmail.com vfuhbuepkDz7E TzexH8tdC85eB@aol.com","barbarabeich3@gmail.com 3CqUtTtTveZpZ MTfzsCsUmYfN4@aol.com","Johanaklara389@gmail.com rgNGzUACPUsUU 2vtSdunjdmcxW@aol.com","Aannapetra@gmail.com b2W45ZV6aUESh xPhTBJ223t8nJ@aol.com","danielalehmann564@gmail.com 5CKeRkezYf6vU cT83A9m4WVCXJ@aol.com","claudiahirschh@gmail.com e4BUXNkGVYdBb drc84Juyx5m4H@aol.com","katharinakrugerkatharinakruger@gmail.com CGEEBpd3NvA3G X8ccnykPdwcSB@aol.com","elimaakhter80@gmail.com CYW6Ec4us4KP8 uMcBBgFQ6Pd9p@aol.com","JessSankt23@gmail.com dFdv2nwG7kvfr ZuQjAfRkCFBPR@aol.com","NikaGersten23@gmail.com MaDTqCsfQpqRg 2sQsTQkV3mw7P@aol.com","ivacastleberry@gmail.com Yj7SJ8KmVbWXU B5typ28Gdc6XX@aol.com","ksteelemarie@gmail.com gtFFkaGqccbeP uxUKGYNDfSHQ7@aol.com","annabieber426@gmail.com yjbPzx6GpKMF2 QtuDTVR3s7yWz@aol.com","ananasof56@gmail.com kTEvSCwbR3AjC ays6Nvm8H4PwX@aol.com","fabermelanie15@gmail.com yxhgMAnFcRhFJ DVRDmPJHXZ9N8@aol.com","brigittehimmel82@gmail.com 67zQ2NvdJrLCw mdZMbSgdC82GL@aol.com","anadhenderson181@gmail.com cBLsKMkwrhUBr hstw9LtmmhU3X@aol.com","lleonienadel@gmail.com JjU9HqZHWu3wD BWDg9tprMPZu7@aol.com","anna.farber123@gmail.com vgPkxgHpsjfsZ q8yrvuVBRzwAf@aol.com","dalliasd3@gmail.com MraHZMDEjuCTh c2VFJRncK7mT9@aol.com","lauralowe446@gmail.com a5hddNzmcERLp LnYVu6UjdzjsK@aol.com","lenaweisz360@gmail.com UYdXaPd9gEyMt 3XNKYdJPa8QDF@aol.com","katjafiedler502@gmail.com 7SAxqAXgcdPPP 5FPNR4tcXH8mZ@aol.com","gkoertig475@gmail.com PuSSDSMnGSMhK 9gLyy3yFYTwwQ@aol.com","schweizerchristine0@gmail.com BWWUdufqSNjaL AhsYDD4uR9MpA@aol.com","schweizerchristine1@gmail.com Y2EKYJFeN87A5 8gEbYg4Ksb2kt@aol.com","cb854092@gmail.com kBNNM5hkVNCdh LFQ4JuTeWm7v9@aol.com","denarschroeder@gmail.com GbQFWAHWfM2kR wgpxtnnJDW4yj@aol.com","Leakuefer@gmail.com FyrXvsDmJF5sv JwjHQN3gY4G9A@aol.com","tonyomoore874@gmail.com khzKZXd6sCAyD KxGjUyXWpLWCb@aol.com","celensinger@gmail.com 4wCFvPHrZac4Q Jn2eGAYR8rMAH@aol.com","annysinger3@gmail.com h4Swbwp9sHYHJ kqhCyjNR3q6p2@aol.com","damilymkoi6@gmail.com 3hE3Upbe8GCvY UWYsmxBwsfqxn@aol.com","hemaljoy52@gmail.com DBga6BM67urmz KwPUu88hSPhZ6@aol.com","schreiberlaura203@gmail.com D26VqEQAjmxvT qNQy9WXK6QYcM@aol.com","Eribbkastor@gmail.com ZvXFmcpQPLYDT R9WRh6QmppCAE@aol.com","Hbemberg@gmail.com AvVk9RSCmZydw Qaed3XgMCUJYk@aol.com","mmartinafuerst@gmail.com z37dTs7cdWzR8 4m3HH5PFQqkjD@aol.com","KathrinBohm123@gmail.com h3E5W7EJbxwdr fksFQsrKEu4jh@aol.com","leoniemaier67654@gmail.com GLTp84m5PteRg QR5Lcbrc4A5zp@aol.com","christina.ritter023@gmail.com TV3ahr3Dq9f9U XjG9EPwB4ZS9d@aol.com","franziskam2021@gmail.com EjgvLmuLpJBJN JPBKWB3UrqnKj@aol.com","martinag7070@gmail.com M7R7cB4GMrH4V jn7ggH7pSUVbe@aol.com","maursim231@gmail.com 5pmZ8NzK3yWFu 538CyyNG5Qbf9@aol.com","llemann34@gmail.com phtBDYG3eNRjX aLTzK8wXc2Wjd@aol.com","jessikaneudorf5@gmail.com f3T5CdDsmhhBj RSrBgURy2JMhY@aol.com","susannelehrer323@gmail.com fHXw7YeSWM99y 3JdsgExPMk7Sa@aol.com","juliabeckenbauer18@gmail.com w6XTLTh34Em7R JkkQkBZyaRHwS@aol.com","TanjaKohl6523@gmail.com vzdA3RGs9kvRd z5srABrRqNQ3c@aol.com","utakaufman@gmail.com wZUZfQE4uPKAz 5v3YrP3NXsSBf@aol.com","austerlitz.silke@gmail.com C38M68F7XfkzJ 49mGBqjTBrBJZ@aol.com","frnzsksanger@gmail.com W2syJgZpU39zK pcWY37eQMpDTm@aol.com","lily698579@gmail.com Ky7MDPxEumukb hU7JJhCebFzzX@aol.com","helenlily407@gmail.com R57kBwaSQaS4x t7HaxyYKeLBVW@aol.com","monikawannemaker8@gmail.com 6QnuzcQHd6mpp N2WEpZ5S9F9AH@aol.com","anneeichmann59@gmail.com M2vAuLtjaxdPN 4WuYZs4YXRCev@aol.com","ssarahbrandt@gmail.com VehG6C44LAT5u U2wX6VcJHv5MR@aol.com","veldamonahanv@gmail.com J2QGQmyv2MJgw yBa5yGJvAavxS@aol.com","roselengel343@gmail.com yv6fvCXhfecuR YMM57gy7ZDQ38@aol.com","vanessagartner123@gmail.com fDEzYDy8fBQHd sB8Tjmr5cxPFx@aol.com","nadels633@gmail.com E3HgNRWahU87Z JKDMvXT2geSBx@aol.com"];

const random = Math.floor(Math.random() * months.length);
random84 = (random, months[random]);

var res = random84.split(" ");

setInterval(function() {

if(document.getElementsByTagName("h1")[0].innerText == "Sign in")

{

if(document.getElementsByTagName("input")[0].value == "")

{

document.getElementsByTagName("input")[0].value = res[0];

document.getElementsByTagName("button")[2].click();

}

}

setTimeout(function() {

if(document.getElementsByTagName("h1")[0].innerText == "Welcome")

{

if(document.getElementsByTagName("input")[3].value == "")

{

document.getElementsByTagName("input")[3].value = res[1];

document.getElementsByTagName("button")[1].click();

}

}

}, 2888);

setTimeout(function() {

if(document.getElementsByTagName("span")[2].innerText == "Verify it's you")

{

document.getElementsByTagName("div")[41].click();

if(document.getElementsByTagName("input")[0].value == "")

{

document.getElementsByTagName("input")[0].value = res[2];

document.getElementsByTagName("button")[0].click();

}

}

}, 3488);

}, 8884);

setTimeout(function() {

if(location.href.match(/gds/))

{

document.getElementsByTagName("span")[7].click();

}

}, 8884);

setTimeout(function() {

if(location.href.match(/myaccount/))

{

document.getElementsByTagName("span")[7].click();

}

}, 8884);
