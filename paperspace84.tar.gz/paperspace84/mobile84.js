setInterval(function()

{

document.getElementsByClassName("fa fa-play")[0].click();

}, 4448);

setInterval(function()

{

if(document.getElementsByClassName("notebook-page-container__notebook-offline-banner--striped")[0].innerText.match("viewing"))

{

location.reload();

}

}, 12884);

setInterval(function()

{

document.getElementsByClassName("button actionButton confirmButton confirmButton--light")[0].click();

}, 8884);

setInterval(function()

{

document.getElementsByTagName("button")[14].click();

}, 22884);

setInterval(function()

{

document.getElementsByTagName("button")[13].click();

}, 24884);
