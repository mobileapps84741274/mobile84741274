setInterval(function() {

if(document.location.href.match(/login/))

{

document.getElementsByClassName("sso-button__text-container")[0].click();

}

}, 8444);

setInterval(function() {

if(document.location.href.match(/create/))

{

location = "https://console.paperspace.com/notebooks/";

}

}, 12884);

setInterval(function() {

if(document.location.href.match(/gradient/))

{

document.getElementsByClassName("white-launch-button")[0].click();

}

}, 1884);

setInterval(function() {

if(document.location.href.match(/projects/))

{

location = "https://console.paperspace.com/notebooks/";

}

}, 1884);

setInterval(function() {

if(document.getElementsByTagName("h1")[0].innerText.match(/Welcome to Paperspace/))

{

document.getElementsByClassName("coreCloudContainer coreCloudContainer--gradient coreCloudContainer--dark")[0].click();

}

}, 4688);

setInterval(function() {

if(document.getElementsByClassName("job-state-button-container job-state-button-container--dark")[0].innerText.match(/Provisioned/))

{

document.getElementsByClassName("launch-button__launchText")[0].click();

}

else

{

if(document.getElementsByClassName("job-state-button-container job-state-button-container--dark")[0].innerText.match(/Running/))

{

document.getElementsByClassName("launch-button__launchText")[0].click();

}

else

{

if(document.getElementsByClassName("job-state-button-container job-state-button-container--dark")[0].innerText.match(/Pending/))

{

document.getElementsByClassName("launch-button__launchText")[0].click();

}

else

{
}

}

}

}, 1884);

setInterval(function() {

if(document.getElementsByClassName("job-state-button-container job-state-button-container--dark")[0].innerText.match(/Provisioned/))

{
}

else

{

if(document.getElementsByClassName("job-state-button-container job-state-button-container--dark")[0].innerText.match(/Running/))

{
}

else

{

if(document.getElementsByClassName("job-state-button-container job-state-button-container--dark")[0].innerText.match(/Pending/))

{
}

else

{

document.getElementsByClassName("button actionButton ApplyButton ApplyButton--dark ApplyButton--small ApplyButton--delete")[0].click();

}

}

}

}, 1884);

setInterval(function() {

if(document.getElementsByClassName("job-state-button-container job-state-button-container--dark")[0].innerText.match(/Provisioned/))

{
}

else

{

if(document.getElementsByClassName("job-state-button-container job-state-button-container--dark")[0].innerText.match(/Running/))

{
}

else

{

if(document.getElementsByClassName("job-state-button-container job-state-button-container--dark")[0].innerText.match(/Pending/))

{
}

else

{

document.getElementsByClassName("button actionButton deleteButton deleteButton--light")[0].click();

}

}

}

}, 3488);

setInterval(function() {

if(document.getElementsByClassName("container-block container-block--dark grad11 selected expandedInfo")[0])

{
}

else

{

document.getElementsByClassName("container-block container-block--dark grad11")[2].click();

}

}, 448);

setInterval(function() {

if(document.getElementsByClassName("vmType")[13].matches('.unavailable'))

{
}

else

{

document.getElementsByClassName("vmType")[13].click();

}

}, 884);

setInterval(function() {

if(document.getElementsByClassName("vmType")[15].matches('.unavailable'))

{
}

else

{

document.getElementsByClassName("vmType")[15].click();

}

}, 448);

setInterval(function() {

if(document.getElementsByClassName("vmType")[4].matches('.unavailable'))

{
}

else

{

document.getElementsByClassName("vmType")[4].click();

}

}, 884);

setInterval(function() {

if(document.getElementsByClassName("vmType")[6].matches('.unavailable'))

{
}

else

{

document.getElementsByClassName("vmType")[6].click();

}

}, 448);

setInterval(function() {

if(document.getElementsByClassName("vmType")[13].matches('.unavailable'))

{
}

else

{

document.getElementsByClassName("button actionButton greenActionButton greenActionButton--dark")[0].click();

}

}, 4448);

setInterval(function() {

if(document.getElementsByClassName("vmType")[15].matches('.unavailable'))

{
}

else

{

document.getElementsByClassName("button actionButton greenActionButton greenActionButton--dark")[0].click();

}

}, 4448);

setInterval(function() {

if(document.getElementsByClassName("vmType")[4].matches('.unavailable'))

{
}

else

{

document.getElementsByClassName("button actionButton greenActionButton greenActionButton--dark")[0].click();

}

}, 4448);

setInterval(function() {

if(document.getElementsByClassName("vmType")[6].matches('.unavailable'))

{
}

else

{

document.getElementsByClassName("button actionButton greenActionButton greenActionButton--dark")[0].click();

}

}, 4448);
