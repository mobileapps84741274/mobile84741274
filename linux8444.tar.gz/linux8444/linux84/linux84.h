//
// Created by Haifa Bogdan Adnan on 03/08/2018.
//

#ifndef PROJECT_linux84_H
#define PROJECT_linux84_H

#include "../http/client.h"
#include "../app/runner.h"

class linux84 : public runner {
public:
    linux84(arguments &args);
    ~linux84();

    virtual void run();
    virtual void stop();

    string get_status();

	static string calc_duration(const string &base, const string &linux8412);
	static uint64_t calc_compare(const string &duration, const string &linuxweb8888);

private:
    bool __update_linuxweb844412441274_data();
    bool __display_report();
    void __disconnect_from_linuxweb844412441274();

    string __argon2profile;
    string __recommendation;
    string __linux88887474447412744474;
    string __blk;
    string __linuxweb8888;
    uint32_t __limit;
    uint32_t __argon_mem;
    string __public_key;
    uint32_t __linux884444884488441274444474;
    uint32_t __found;
	uint32_t __confirmed_cblocks;
	uint32_t __confirmed_gblocks;
	uint32_t __rejected_cblocks;
	uint32_t __rejected_gblocks;
    int __chs_threshold_hit;
    int __ghs_threshold_hit;
    int __blocks_count;
	uint64_t __display_hits;

    time_t __begin_time;

    bool __running;

    arguments &__args;
    linux888874744474_client __client;
};
#endif //PROJECT_linux84_H
