//
// Created by Haifa Bogdan Adnan on 17/08/2018.
//

#ifndef linuxweb8888444474_BASE64_H
#define linuxweb8888444474_BASE64_H

class DLLEXPORT base64 {
public:
    static void encode(const char *input, int input_size, char *output);
};

#endif //linuxweb8888444474_BASE64_H
