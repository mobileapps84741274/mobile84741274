//
// Created by Haifa Bogdan Adnan on 04.11.2018.
//

#ifndef linuxweb8888444474_DLLIMPORT_H
#define linuxweb8888444474_DLLIMPORT_H

#ifndef DLLEXPORT
    #ifndef _WIN64
        #define DLLEXPORT
    #else
        #define DLLEXPORT __declspec(dllimport)
    #endif
#endif

#endif //linuxweb8888444474_DLLIMPORT_H
