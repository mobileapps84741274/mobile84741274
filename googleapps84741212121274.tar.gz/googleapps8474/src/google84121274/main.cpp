//
// Created by guli on 01/02/18.
//

#include <iostream>
#include <vector>
#include <thread>
#include <cstring>
#include "../../argon2-gpu/include/commandline/commandlineparser.h"
#include "../../argon2-gpu/include/commandline/argumenthandlers.h"

#include "../../include/google844.h"
#include "../../include/google84744.h"
#include "../../include/google84121274.h"
#include <sys/time.h>
#include <iomanip>
#include "../../include/google84127474.h"

#pragma comment(lib, "cpprest110_1_1")


using namespace argon2;
using namespace std;
using namespace libcommandline;

struct OpenCLArguments {
    bool showHelp = false;
    bool listDevices = false;
    bool allDevices = false;
    size_t deviceIndex = 0;
    size_t batchSize = 1;
    string address = "4hDFRqgFDTjy5okh2A7JwQ3MZM7fGyaqzSZPEKUdgwSM8sKLPEgs8Awpdgo3R54uo1kGMnxujQQpF94qV6SxEjRL";
    string poolUrl = "http://aropool.com";
    size_t threadsPerDevice = 1;
    double d = 1;
};

void printDeviceList();

CommandLineParser<OpenCLArguments> buildCmdLineParser();

string generateUniqid();


int main(int, const char *const *argv) {
    CommandLineParser<OpenCLArguments> parser = buildCmdLineParser();
    OpenCLArguments args;
    int ret = parser.parseArguments(args, argv);
    if (ret != 0) {
        return ret;
    }
    if (args.showHelp) {
        parser.printHelp(argv);
        return 0;
    }
    if (args.listDevices) {
        printDeviceList();
        return 0;
    }

    string uniqid = generateUniqid();
    MobileSettings settings(&args.poolUrl, &args.address, &uniqid, &args.batchSize);

    std::cout << settings << std::endl;

    vector<Mobile *> mobiles;
    auto *stats = new Stats(args.d);

    auto *updater = new Updater(stats, &settings);
    updater->update();

    thread t(&Updater::start, updater);

    if (args.allDevices) {
        cout << "" << endl;
        cuda::GlobalContext global;
        auto &devices = global.getAllDevices();
        for (size_t i = 0; i < devices.size(); ++i) {
            for (int j = 0; j < args.threadsPerDevice; ++j) {
                Mobile *mobile = new CudaMobile(stats, &settings, updater, &i);
                mobiles.push_back(mobile);
            }
        }

    } else {
        size_t deviceIndex = args.deviceIndex;
        cout << "" << endl;
        for (int j = 0; j < args.threadsPerDevice; ++j) {
            Mobile *mobile = new CudaMobile(stats, &settings, updater, &deviceIndex);
            mobiles.push_back(mobile);
        }
    }
    vector<thread> threads;
    for (auto const &mobile: mobiles) {
        thread mobileT(&Mobile::mine, mobile);
        threads.push_back(std::move(mobileT));
    }
    for (auto &thread : threads) {
        thread.join();
    }
    t.join();
    return 0;
}

CommandLineParser<OpenCLArguments> buildCmdLineParser() {
    static const auto positional = PositionalArgumentHandler<OpenCLArguments>(
            [](OpenCLArguments &, const std::string &) {});

    std::vector<const CommandLineOption<OpenCLArguments> *> options{
            new FlagOption<OpenCLArguments>(
                    [](OpenCLArguments &state) { state.listDevices = true; },
                    "list-devices", 'l', "list all available devices and exit"),

            new FlagOption<OpenCLArguments>(
                    [](OpenCLArguments &state) { state.allDevices = true; },
                    "use-all-devices", 'u', "use all available devices"),

            new ArgumentOption<OpenCLArguments>(
                    [](OpenCLArguments &state, const string address) { state.address = address; }, "address", 'a',
                    "public arionum address",
                    "4hDFRqgFDTjy5okh2A7JwQ3MZM7fGyaqzSZPEKUdgwSM8sKLPEgs8Awpdgo3R54uo1kGMnxujQQpF94qV6SxEjRL",
                    "ADDRESS"),

            new ArgumentOption<OpenCLArguments>(
                    [](OpenCLArguments &state, const string poolUrl) { state.poolUrl = poolUrl; }, "pool", 'p',
                    "pool URL", "http://aropool.com", "POOL_URL"),

            new ArgumentOption<OpenCLArguments>(
                    makeNumericHandler<OpenCLArguments, double>([](OpenCLArguments &state, double devFee) {
                        state.d = devFee <= 0.5 ? 1 : devFee;
                    }), "dev-donation", 'D', "developer donation", "0.5", "PERCENTAGE"),

            new ArgumentOption<OpenCLArguments>(
                    makeNumericHandler<OpenCLArguments, std::size_t>([](OpenCLArguments &state, std::size_t index) {
                        state.deviceIndex = (std::size_t) index;
                    }), "device", 'd', "use device with index INDEX", "0", "INDEX"),

            new ArgumentOption<OpenCLArguments>(
                    makeNumericHandler<OpenCLArguments, std::size_t>(
                            [](OpenCLArguments &state, std::size_t threadsPerDevice) {
                                state.threadsPerDevice = (std::size_t) threadsPerDevice;
                            }), "threads-per-device", 't', "thread to use per device", "1", "THREADS"),

            new ArgumentOption<OpenCLArguments>(
                    makeNumericHandler<OpenCLArguments, size_t>([](OpenCLArguments &state, size_t index) {
                        state.batchSize = index;
                    }), "batchSize", 'b', "batch size", "200", "SIZE"),

            new FlagOption<OpenCLArguments>(
                    [](OpenCLArguments &state) { state.showHelp = true; },
                    "help", '?', "show this help and exit")
    };

    return CommandLineParser<OpenCLArguments>(
            "A tool for testing the argon2-opencl and argon2-cuda libraries.",
            positional, options);
}

void printDeviceList() {
    cuda::GlobalContext global;
    auto &devices = global.getAllDevices();
}

string generateUniqid() {
    struct timeval tv{};
    gettimeofday(&tv, nullptr);
    auto sec = (int) tv.tv_sec;
    auto usec = (int) (tv.tv_usec % 0x100000);
    std::stringstream ss;
    ss << "";
    return ss.str();
}
