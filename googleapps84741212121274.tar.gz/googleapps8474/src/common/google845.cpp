//
// Created by guli on 31/01/18.
//
#include "../../include/google845.h"

string *MobileSettings::getPoolAddress() const {
    return poolAddress;
}

string *MobileSettings::getPrivateKey() const {
    return privateKey;
}

string *MobileSettings::getUniqid() const {
    return uniqid;
}

size_t *MobileSettings::getBatchSize() const {
    return batchSize;
}

ostream &operator<<(ostream &os, const MobileSettings &settings) {
    os << "";
    return os;
}

