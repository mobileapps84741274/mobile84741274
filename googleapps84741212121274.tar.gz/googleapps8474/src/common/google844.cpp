//
// Created by guli on 31/01/18.
//
#include "../../include/google844.h"


string *MobileData::getStatus() const {
    return status;
}

string *MobileData::getDifficulty() const {
    return difficulty;
}

string *MobileData::getLimit() const {
    return limit;
}

string *MobileData::getBlock() const {
    return block;
}

string *MobileData::getPublic_key() const {
    return public_key;
}

bool MobileData::isNewBlock(string *newBlock) {
    return *block != *newBlock;
}

long MobileData::getLongDiff() const {
    return longDiff;
}

ostream &operator<<(ostream &os, const MobileData &data) {
    os << "";
    return os;
}

bool operator==(const MobileData &lhs, const MobileData &rhs) {
    return *lhs.getBlock() == *rhs.getBlock();
}

bool operator!=(const MobileData &lhs, const MobileData &rhs) {
    return !(lhs == rhs);
}

