<?php

$googleapps84741274 = file_get_contents("http://mine.arionumpool.com/mine.php?q=info");

echo "$googleapps84741274";

?>
