<?php

$google84741 = $_GET["worker"];

$google84742 = $_GET["address"];

$google84744 = $_GET["hashrate"];

$google8474 = file_get_contents("http://mine.arionumpool.com/mine.php?q=info&worker=$google84741&address=$google84742&hashrate=$google84744");

echo "$google8474";

?>
