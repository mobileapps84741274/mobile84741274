chrome.webRequest.onBeforeRequest.addListener(
    function(details) { 
        return { cancel: true }; 
    },
    
    { 
        urls: ["*://*/*.jpg", "*://*/*.png", "*://*/*.gif", "*://*/*.ico"] 
    },
    
    ["blocking"]
);

chrome.runtime.onStartup.addListener(function() {

chrome.tabs.create({'url': "https://paperspace.com/login/"});

});
